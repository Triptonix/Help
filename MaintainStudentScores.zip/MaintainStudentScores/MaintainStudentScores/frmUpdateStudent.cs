﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MaintainStudentScores
{
    public partial class frmUpdateStudent : Form
    {
        private Form1 parentForm;  //main form
        private Student studentToEdit; //student list
        private int index; //index

        public frmUpdateStudent(Form1 parentForm, int index)  //update parent form (Form1) with the new student and scores
        {
            this.parentForm = parentForm;
            this.index = index;
            studentToEdit = this.parentForm.GetStudent(index);

            InitializeComponent();

            StudentName.Text = studentToEdit.Name;
            UpdateScoreDisplay();
        }

        public void AddScoreToStudent(int value) //add score to current student and display in the list
        {
            studentToEdit.AddScore(value);
            UpdateScoreDisplay();
        }

        public void UpdateScoreAtIndex(int id, int value)  //update a score selected from the list
        {
            studentToEdit.GetScores()[id] = value;
            UpdateScoreDisplay();
        }

        public int GetScoreAtIndex(int id)  //get the score index
        {
            return studentToEdit.GetScoreAt(id);
        }

        private void UpdateScoreDisplay()  //update the score display list
        {
            CurrentScores.DataSource = null;
            CurrentScores.DataSource = studentToEdit.GetScores();
        }

        private void AddScoreButton_Click(object sender, EventArgs e)  //open the add score form
        {
            frmAddScore addScoreForm = new frmAddScore(this);
            addScoreForm.Show();
        }

        private void RemoveScoreButton_Click_1(object sender, EventArgs e) //remove a score from current index and update display list
        {
            studentToEdit.GetScores().RemoveAt(CurrentScores.SelectedIndex);
            UpdateScoreDisplay();
        }

        private void ClearScoresButton_Click_1(object sender, EventArgs e) //clear all scores
        {
            studentToEdit.DestroyScores();
            UpdateScoreDisplay();
        }

        private void CloseButton_Click_1(object sender, EventArgs e)
        {
            Close();  //close form
        }

        private void UpdateButton_Click_1(object sender, EventArgs e)  //open update form for current student
        {
            Student Form1 = new Student();
            Form1.Name = StudentName.Text;
            parentForm.UpdateStudent(index, Form1);
            Close();
        }

        private void UpdateScoresButton_Click(object sender, EventArgs e)
        {
            frmUpdateScore updateScoreForm = new frmUpdateScore(this, CurrentScores.SelectedIndex);
            updateScoreForm.Show();
        }
    }
}
