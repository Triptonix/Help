﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MaintainStudentScores
{
    public partial class Form1 : Form
    {
        public List<Student> studentList = new List<Student>();
        private int id; //index of score
        private int _selectedIndex;

        public Form1()
        {
            InitializeComponent();

            students.DataSource = studentList;  //Show students.
            students.DisplayMember = "Name";  //Display their name
        }

        public void UpdateStudentList(int _selectedIndex)
        {
            students.DataSource = null;
            students.DataSource = studentList;
            students.DisplayMember = "Name";
        }

        public bool AddStudent(Student studentToAdd)
        {
            try
            {
                studentList.Add(studentToAdd); //add student to the list.
                UpdateStudentList(_selectedIndex); //update student list.
            }
            catch { return false; }
            return true;
        }

        public bool UpdateStudent(int originalIndex, Student studentToEdit)
        {
            try
            {
                Student student = GetStudent(originalIndex);  //select index of student
                student.Name = studentToEdit.Name;  //name of student
                studentList.RemoveAt(originalIndex); //remove the student at the index selected
                studentList.Insert(originalIndex, student); //insert new student at index.
                UpdateStudentList(originalIndex); //update student list
            }
            catch { return false; }
            return true;
        }



        public Student GetStudent(int id)  //Get student index
        {
            return studentList[id];
        }

        public bool DeleteStudent(int id) //remove student at index.
        {
            try
            {
                studentList.RemoveAt(id);
                UpdateStudentList(_selectedIndex);
            }
            catch { return false; }
            return true;
        }

        private void updateStudent_Click_1(object sender, EventArgs e)
        {
            frmUpdateStudent frmupdateStudent = new frmUpdateStudent(this, students.SelectedIndex); //pass curent info to new form
            frmupdateStudent.Show(); //open new form
        }

        private void deleteStudent_Click_1(object sender, EventArgs e)
        {
            if (!DeleteStudent(_selectedIndex))  //check if student is selected from list.
                MessageBox.Show("Error deleting student..."); //throw message box saying that a student isn't selected.
        }

        private void ExitButton_Click_1(object sender, EventArgs e)
        {
            Dispose();  //clear everything
            Close();  //close form
        }

        private void addStudent_Click(object sender, EventArgs e)
        {
            frmAddStudent frmaddStudent = new frmAddStudent(this);  //pass info to new form
            frmaddStudent.Show(); // open new form
        }

        private void students_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            _selectedIndex = students.SelectedIndex;

            if (_selectedIndex > -1)
            {

                Student student = GetStudent(_selectedIndex); //select index from list

                Student students = GetStudent(_selectedIndex);  //select index from list
                ScoreTotalTextBox.Text = student.GetScoreTotal().ToString(); //show Score Total to box
                ScoreCountTextBox.Text = student.GetScoreCount().ToString(); //show Score Count to box
                ScoreAverageTextBox.Text = student.GetScoreAverage().ToString(); //show Score Average to box               
            }
        }
    }
}
